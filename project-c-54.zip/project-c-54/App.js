import React, { Component } from 'react';
import { Text, View, StyleSheet, Button, Alert } from 'react-native';


export default class App extends Component {

  render() {
    return (
      <View style={{ width:200, height:200, marginTop:80, marginLeft:70, }}>
        <Button
        title="sound1"
        color = "red"
        onPress={() => Alert.alert('Play Sound 1')}>
        </Button>
        <Button
        title="sound2"
        color = "blue"
        onPress={() => Alert.alert('Play Sound 2')}>
        </Button>
        <Button
        title="sound3"
        color = "green"
        onPress={() => Alert.alert('Play Sound 3')}>
        </Button>
        <Button
        title="sound4"
        color = "purple"
        onPress={() => Alert.alert('Play Sound 4')}>
        </Button>
        </View>
    );
  }
}
